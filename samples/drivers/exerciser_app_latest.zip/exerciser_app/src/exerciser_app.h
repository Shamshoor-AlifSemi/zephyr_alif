#ifndef EXERCISER_APP_H
#define EXERCISER_APP_H
 
void blinky_thread(void);
void ospi_thread(void);
void spi_thread(void);
void sd_thread(void);
void usb_thread(void);
void pdm_thread(void);
void i2s_thread(void);
 
#endif // EXERCISER_APP_H
